package com.example.tamagotchi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }
    public void GoChoosingPet(View V){
        Intent intent = new Intent(this, choosing_pet.class);
        startActivity(intent);
    }

    public void GoHelp(View V){
        Intent intent = new Intent(this, help.class);
        startActivity(intent);
    }

}