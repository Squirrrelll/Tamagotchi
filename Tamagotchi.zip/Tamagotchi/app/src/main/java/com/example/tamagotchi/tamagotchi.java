package com.example.tamagotchi;

import static android.icu.lang.UCharacter.GraphemeClusterBreak.V;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.TimeUnit;


public class tamagotchi extends AppCompatActivity {

    private TextView textName;
    private TextView NeedFood;


    private Pet myPet;
    Handler handler;

    private TextView DeathText;
    private TextView DeathTime;
    private TextView textfirst;
    private TextView timefirst;
    private TextView textsecond;
    private TextView timesecond;
    private TextView textthird;
    private TextView timethird;

    private TextView NeedWater;
    private TextView NeedSleep;
    private TextView NeedBeHappy;
    private TextView Z1;
    private TextView Z2;
    private TextView Znak;
    private TextView NAME;
    private TextView first;//////////
    private TextView RightAnswer;
    private ImageView ImageViewPet;
    private ImageView ImageLight;
    private ImageView ImageBed;
    private ImageButton BtnSleep;
    private ImageButton BtnMeal;
    private ImageButton BtnWater;
    private ImageButton BtnHappy;
    private Button llbutton;
    private ImageButton Back;
    private LinearLayout linerlayout;
    private LinearLayout linearLayout2;
    private LinearLayout linerlayout1;
    private LinearLayout ACH;
    private boolean SleepWasClicked;
    private boolean PlayWasClicked;
    ///////////////////////////////////
    private Boolean win = false;
    private int TryNumber;
    private int RandomNumber1;
    private int RandomNumber2;
    private String Answer;
    private EditText PlayerAnswer;
    private Button Try;
    private ObjectAnimator PetAnimator;
    // Displays
    private Display display;

    // Points
    private Point size;
    private int width;
    private int height;
    private long startSleep;
    private long stopSleep;
    private long awayTimeSleep;
    private long awayTime;
    private int timeSleep;
    private int timeMeal;
    private int timeWater;
    private int timeHappy;
    private int timeDeath;
    private String[] Array = new String[9];

    /**
     * Изменение изображения при высоких и низких параметрах
     */
    public void updateMood() {
        int food = myPet.getFood();
        int water = myPet.getWater();
        int sleep = myPet.getSleep();
        int happy = myPet.getHappy();
        if (!SleepWasClicked) {
            if (food >= 70 && water >= 70 && sleep >= 70 && happy >= 70) {
                if (myPet.getKind().equals("kitty")) {
                    ImageView imageView = findViewById(R.id.imageViewPet);
                    imageView.setImageResource(R.drawable.kitty_happy);
                } else if (myPet.getKind().equals("rabbit")) {
                    ImageView imageView = findViewById(R.id.imageViewPet);
                    imageView.setImageResource(R.drawable.rabbit_happy);
                }
            } else if (food <= 30 || water <= 30 || sleep <= 30 || happy <= 30) {
                if (myPet.getKind().equals("kitty")) {
                    ImageView imageView = findViewById(R.id.imageViewPet);
                    imageView.setImageResource(R.drawable.kitty_sad);
                } else if (myPet.getKind().equals("rabbit")) {
                    ImageView imageView = findViewById(R.id.imageViewPet);
                    imageView.setImageResource(R.drawable.rabbit_sad);
                }
            } else {
                if (myPet.getKind().equals("kitty")) {
                    ImageView imageView = findViewById(R.id.imageViewPet);
                    imageView.setImageResource(R.drawable.kitty_normal);
                } else if (myPet.getKind().equals("rabbit")) {
                    ImageView imageView = findViewById(R.id.imageViewPet);
                    imageView.setImageResource(R.drawable.rabbit_normal);
                }
            }
        } else if (SleepWasClicked) {
            if (myPet.getKind().equals("kitty")) {
                ImageView imageView = findViewById(R.id.imageViewPet);
                imageView.setImageResource(R.drawable.kitty_sleep);
            } else if (myPet.getKind().equals("rabbit")) {
                ImageView imageView = findViewById(R.id.imageViewPet);
                imageView.setImageResource(R.drawable.rabbit_sleep);
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tamagotchi);
        //   setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        for (int i = 0; i < 9; i++) {
            Array[i] = String.valueOf(0);
        }
     //   mSettings = getSharedPreferences(APP_PREFERENCES, Context.MODE_PRIVATE);
        textName = findViewById(R.id.textName);

        //init();
        //   textName.setText(pref.getString(save_name,"пусто"));
    /*   load();


        myPet.setFood(pref.getInt(save_food,0));
        SharedPreferences.Editor edit = pref.edit();
        edit.putInt(save_food, myPet.getFood());
        edit.apply();
*/
        Bundle arguments = getIntent().getExtras();
        /** Айдишники */
        DeathTime = findViewById(R.id.TEXTtime);
        DeathText = findViewById(R.id.TEXT);
        textfirst = findViewById(R.id.first);
        timefirst = findViewById(R.id.timefirst);
        textsecond = findViewById(R.id.second);
        timesecond = findViewById(R.id.timesecond);
        textthird = findViewById(R.id.third);
        timethird = findViewById(R.id.timethird);
        Z1 = findViewById(R.id.textZ);
        Z2 = findViewById(R.id.Z2);

        NeedFood = findViewById(R.id.needfood);
        NeedWater = findViewById(R.id.needwater);
        NeedSleep = findViewById(R.id.needsleep);
        NeedBeHappy = findViewById(R.id.needbehappy);
        ImageViewPet = findViewById(R.id.imageViewPet);
        BtnSleep = findViewById(R.id.btnsleep);
        BtnMeal = findViewById(R.id.btnmeal);
        BtnWater = findViewById(R.id.btnwater);
        BtnHappy = findViewById(R.id.btnhappy);
        ImageLight = findViewById(R.id.ImageLight);
        linerlayout = findViewById(R.id.linearLayout);
        linerlayout1 = findViewById(R.id.linearLayout3);
        linearLayout2 = findViewById(R.id.linearLayout2);
        ImageBed = findViewById(R.id.imageBed);
        Back = findViewById(R.id.backtomenufromhelp);
        ACH = findViewById(R.id.llach);
        // llbutton.setClickable(false);

        size = new Point();
        display = getWindowManager().getDefaultDisplay();
        display.getSize(size);
        // Ints
        width = size.x;
        height = size.y;
        findViewById(R.id.mainall).setOnTouchListener(handleTouch);

        /** Кнопка сна */

        BtnSleep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!SleepWasClicked) {
                    startSleep = System.currentTimeMillis();
                    ImageLight.setVisibility(View.VISIBLE);
                    SleepWasClicked = true;
                    BtnMeal.setClickable(false);
                    BtnWater.setClickable(false);
                    BtnHappy.setClickable(false);

                } else {
                    stopSleep = System.currentTimeMillis();
                    awayTimeSleep = (stopSleep - startSleep) / 1000 / 60;
                    startSleep = 0;
                    stopSleep = 0;
                    SleepWasClicked = false;
                    ImageLight.setVisibility(View.GONE);
                    BtnMeal.setClickable(true);
                    BtnWater.setClickable(true);
                    BtnHappy.setClickable(true);
                    myPet.updateSleep(awayTimeSleep);
                }

            }
        });
        /** Кнопка еды */
        BtnMeal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myPet.getSleep() >= 2) {
                    myPet.updateFood(10);
                    myPet.updateSleep(-2);
                    myPet.updateHappy(2);
                }

            }
        });
        /** Кнопка воды */
        BtnWater.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myPet.getSleep() >= 1) {

                    myPet.updateWater(15);
                    myPet.updateSleep(-1);
                    myPet.updateHappy(1);
                    //       myPet.ageUp((int) (currentTimeMillis() / 1000));

                }
            }
        });
        /**Выбор имени и вида питомца */
        String pet_kind = arguments.get("pets").toString();
        String pet_name = arguments.get("name").toString();
        myPet = new Pet(pet_name, pet_kind);
        if (pet_kind.equals("kitty")) {

            ImageViewPet.setImageResource(R.drawable.kitty_normal);
        } else if (pet_kind.equals("rabbit")) {

            ImageViewPet.setImageResource(R.drawable.rabbit_normal);
        }
        textName.setText(pet_name);
        /**Потребление параметров в течение времени*/
        handler = new Handler();
        handler.post(ShowAll);
        handler.post(ChangeFood);
        handler.post(ChangeWater);
        handler.post(ChangeSleep);
        handler.post(ChangeHappy);
        handler.post(ChangeDeath);
        //       handler.post(PlusSleep);
    }

    /**
     * Вывод параметров
     */
    Runnable ShowAll = new Runnable() {////!!!
        @Override
        public void run() {
            NeedFood.setText("" + myPet.getFood());
            NeedWater.setText("" + myPet.getWater());
            NeedSleep.setText("" + myPet.getSleep());
            NeedBeHappy.setText("" + myPet.getHappy());
            updateMood();
            if (myPet.getDeath() < 100) awayTime += 1;
            else {

                linerlayout.setVisibility(View.INVISIBLE);
                linerlayout1.setVisibility(View.INVISIBLE);
                ImageBed.setVisibility(View.INVISIBLE);
                ImageLight.setVisibility(View.INVISIBLE);
                textName.setVisibility(View.INVISIBLE);
                ImageViewPet.setVisibility(View.INVISIBLE);
                Z1.setVisibility(View.INVISIBLE);
                Z2.setVisibility(View.INVISIBLE);
                linearLayout2.setVisibility(View.INVISIBLE);
                ACH.setVisibility(View.VISIBLE);
                awayTime = 646362;
                int d = (int) (awayTime / 86400);
                int h = (int) (awayTime % 86400 / 3600);
                int m = (int) (awayTime % 86400 % 3600 / 60);
                int s = (int) (awayTime % 86400 % 3600 % 60);
                String PlayerTime1 = "Результат питомца " + myPet.getName() + ":";
                String PlayerTime2 = "";
                if (d > 0) PlayerTime2 = PlayerTime2 + d + "д ";
                if (h > 0) PlayerTime2 = PlayerTime2 + h + "ч ";
                if (m > 0) PlayerTime2 = PlayerTime2 + m + "м ";
                if (s > 0) PlayerTime2 = PlayerTime2 + s + "с";
                DeathText.setText(PlayerTime1);
                DeathTime.setText(PlayerTime2);
                if (awayTime > Integer.parseInt(Array[2])) {
                    textfirst.setText("1. " + myPet.getName());
                    timefirst.setText(PlayerTime2);
                    Array[0] = myPet.getName();
                    Array[1] = PlayerTime2;
                    Array[2] = String.valueOf(awayTime);
                } else if (awayTime > Integer.parseInt(Array[5]) && awayTime < Integer.parseInt(Array[2])) {
                    textsecond.setText("2. " + myPet.getName());
                    timesecond.setText(PlayerTime2);
                    Array[3] = myPet.getName();
                    Array[4] = PlayerTime2;
                    Array[5] = String.valueOf(awayTime);
                } else if (awayTime > Integer.parseInt(Array[8]) && awayTime < Integer.parseInt(Array[5])) {
                    textthird.setText("3. " + myPet.getName());
                    timethird.setText(PlayerTime2);
                    Array[6] = myPet.getName();
                    Array[7] = PlayerTime2;
                    Array[8] = String.valueOf(awayTime);
                }
            }
            UpdateLevel();
            handler.postDelayed(ShowAll, 1000);
        }
    };
    Runnable ChangeFood = new Runnable() {
        @Override
        public void run() {
            myPet.updateFood(-1);
            handler.postDelayed(ChangeFood, timeMeal);
        }
    };
    /*   Runnable PlusSleep = new Runnable() {
           @Override
           public void run() {
               if(SleepWasClicked){
               myPet.updateSleep(1);
               handler.postDelayed(PlusSleep, 1000);}
           }
       };*/
    Runnable ChangeWater = new Runnable() {
        @Override
        public void run() {
            myPet.updateWater(-1);
            handler.postDelayed(ChangeWater, timeWater);
        }
    };
    Runnable ChangeSleep = new Runnable() {
        @Override
        public void run() {
            myPet.updateSleep(-1);
            handler.postDelayed(ChangeSleep, timeSleep);
        }
    };
    Runnable ChangeHappy = new Runnable() {
        @Override
        public void run() {
            myPet.updateHappy(-1);
            handler.postDelayed(ChangeHappy, timeHappy);
        }
    };
    Runnable ChangeDeath = new Runnable() {
        @Override
        public void run() {
            if (myPet.getFood() == 0 || myPet.getWater() == 0 || myPet.getSleep() == 0 || myPet.getHappy() == 0)
                myPet.updateDeath(1);
            handler.postDelayed(ChangeDeath, timeDeath);
        }
    };
    private View.OnTouchListener handleTouch = new View.OnTouchListener() {

        @Override
        public boolean onTouch(View v, MotionEvent event) {

            float xC = event.getX();
            float yC = event.getY();

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    break;
                case MotionEvent.ACTION_UP:
                    animatePet(xC, yC);
                    break;
            }
            return true;
        }
    };

    /**
     * Усложнение уровня
     */
    private void UpdateLevel() {
        if (awayTime > 0 && awayTime <= 86400000) {
            timeSleep = 6 * 60 * 1000;
            timeMeal = 4 * 60 * 1000;
            timeWater = 3 * 60 * 1000;
            timeHappy = 5 * 60 * 1000;
            timeDeath = 30 * 60 * 1000;
        } else if (awayTime > 86400000 && awayTime <= 3 * 86400000) {
            timeSleep = 5 * 60 * 1000;
            timeMeal = 7 / 2 * 60 * 1000;
            timeWater = 5 / 2 * 60 * 1000;
            timeHappy = 4 * 60 * 1000;
            timeDeath = 29 * 60 * 1000;
        } else if (awayTime > 3 * 86400000 && awayTime <= 6 * 86400000) {
            timeSleep = 4 * 60 * 1000;
            timeMeal = 5 / 2 * 60 * 1000;
            timeWater = 2 * 60 * 1000;
            timeHappy = 3 * 60 * 1000;
            timeDeath = 28 * 60 * 1000;
        } else if (awayTime > 6 * 86400000 && awayTime <= 10 * 86400000) {
            timeSleep = 3 * 60 * 1000;
            timeMeal = 3 / 2 * 60 * 1000;
            timeWater = 1 * 60 * 1000;
            timeHappy = 2 * 60 * 1000;
            timeDeath = 27 * 60 * 1000;
        } else if (awayTime > 10 * 86400000) {
            timeSleep = 2 * 60 * 1000;
            timeMeal = 1 / 2 * 60 * 1000;
            timeWater = 1 / 2 * 60 * 1000;
            timeHappy = 1 * 60 * 1000;
            timeDeath = 26 * 60 * 1000;
        }
    }

    private void animatePet(float newX, float newY) {
        if (!SleepWasClicked && !PlayWasClicked) {
            PetAnimator = ObjectAnimator.ofFloat(ImageViewPet, "translationX", newX - 500);
            PetAnimator.setDuration(2000);
            PetAnimator.start();
            PetAnimator = ObjectAnimator.ofFloat(ImageViewPet, "translationY", newY - 850);
            PetAnimator.setDuration(2000);
            PetAnimator.start();
        }
    }

    public void GHostBth(View V) {
        int g = 0;
        g = +g;
    }

    /**
     * Игра
     */
    public void Happy(View V) {
        if (myPet.getSleep() >= 5) {

            PlayWasClicked = true;
            linerlayout.setVisibility(View.INVISIBLE);
            linerlayout1.setVisibility(View.INVISIBLE);
            ImageBed.setVisibility(View.INVISIBLE);
            ImageLight.setVisibility(View.INVISIBLE);
            textName.setVisibility(View.INVISIBLE);
            ImageViewPet.setVisibility(View.INVISIBLE);
            /////////////////////////////////////////////
            final TextView number1 = findViewById(R.id.textN1);
            final TextView number2 = findViewById(R.id.textN2);
            RandomNumber1 = (int) (Math.random() * ((1000 - 1) + 1)) + 1;
            RandomNumber2 = (int) (Math.random() * ((1000 - 1) + 1)) + 1;
            number1.setText("" + RandomNumber1);
            number2.setText("" + RandomNumber2);
            Znak = findViewById(R.id.textZ);
            PlayerAnswer = findViewById(R.id.textA);
            Try = findViewById(R.id.textTry);
            RightAnswer = findViewById(R.id.textAnswer);
            number1.setVisibility(View.VISIBLE);
            number2.setVisibility(View.VISIBLE);
            Z1.setVisibility(View.VISIBLE);
            Z2.setVisibility(View.VISIBLE);
            linearLayout2.setVisibility(View.VISIBLE);
            PlayerAnswer.setVisibility(View.VISIBLE);
            Try.setVisibility(View.VISIBLE);
            Back.setVisibility(View.VISIBLE);
            PlayerAnswer.setText("");
            int Sum = RandomNumber1 + RandomNumber2;
            Try.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Answer = PlayerAnswer.getText().toString();
                    if (Answer.length() != 0) {
                        TryNumber = Integer.parseInt(Answer);
                        RightAnswer.setVisibility(View.VISIBLE);
                        if ((Sum) == TryNumber) {
                            RightAnswer.setText("Молодец, это правильный ответ!");
                            win = true;
                        } else {
                            RightAnswer.setText("Неверно, ответ: " + Sum);
                            win = false;
                        }
                        Try.setClickable(false);
                    } else {
                        RightAnswer.setText("Введите ответ");
                        RightAnswer.setVisibility(View.VISIBLE);
                    }

                }
            });
        }
    }

    public void GoTamagotchiAgain(View V) {
        PlayWasClicked = false;
        linerlayout.setVisibility(View.VISIBLE);
        linerlayout1.setVisibility(View.VISIBLE);
        ImageBed.setVisibility(View.VISIBLE);
        textName.setVisibility(View.VISIBLE);
        ImageViewPet.setVisibility(View.VISIBLE);
        Z1.setVisibility(View.INVISIBLE);
        Z2.setVisibility(View.INVISIBLE);
        linearLayout2.setVisibility(View.INVISIBLE);
        PlayerAnswer.setVisibility(View.INVISIBLE);
        Try.setVisibility(View.INVISIBLE);
        Back.setVisibility(View.INVISIBLE);
        RightAnswer.setVisibility(View.INVISIBLE);
        /**Результат игры*/
        Answer = PlayerAnswer.getText().toString();
        if (Answer.length() != 0) {
            if (win) {
                myPet.updateHappy(20);
                myPet.updateSleep(-3);
            } else myPet.updateSleep(-5);
            win = false;
        }

    }

}


