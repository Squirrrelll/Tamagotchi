package com.example.tamagotchi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class choosing_pet extends AppCompatActivity {
    private String ChoosingAPet;
    private Boolean win = false;
    private String name_for_pet;
    private String Name;
    private ImageButton kitty;
    private ImageButton kittytext;
    private ImageButton rabbit;
    private ImageButton rabbittext;
    private EditText name;
    private TextView text;
    private Button save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choosing_pet);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }
    public void GoMenu(View V) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

    }
    public void GoTamagochi(View V) {
        switch (V.getId()) {
            case R.id.kitty:
            case R.id.textkitty:
                ChoosingAPet="kitty";
                break;
            case R.id.rabbit:
            case R.id.textrabbit:
                ChoosingAPet="rabbit";
                break;

        }
        kitty = findViewById(R.id.kitty);
        kitty.setVisibility(View.GONE);

        kittytext = findViewById(R.id.textkitty);
        kittytext.setVisibility(View.GONE);

        rabbit = findViewById(R.id.rabbit);
        rabbit.setVisibility(View.GONE);

        rabbittext = findViewById(R.id.textrabbit);
        rabbittext.setVisibility(View.GONE);

        name = findViewById(R.id.Name);
        name.setVisibility(View.VISIBLE);

        save = findViewById(R.id.Save);
        save.setVisibility(View.VISIBLE);
        text = findViewById(R.id.text);

    }
    public void onClick(View V){
        Name = name.getText().toString();
        if (Name.length() != 0){
        Intent intent = new Intent(this, tamagotchi.class);
        intent.putExtra("game", win);
        intent.putExtra("pets", ChoosingAPet);
        intent.putExtra("name", Name);
        startActivity(intent);}
        else text.setVisibility(View.VISIBLE);
    }


}